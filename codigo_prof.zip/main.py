# Importa as bibliotecas necessárias
import streamlit as st
import pandas as pd
import os

# Carrega os dados dos arquivos CSV
def load_data(file_path):
    if os.path.exists(file_path):
        df = pd.read_csv(file_path)
    else:
        df = pd.DataFrame()
    return df

# Página principal do aplicativo Streamlit
def main():
    st.title('Sistema Inteligente de Cadastro Escolar')

    st.markdown('''
        Este aplicativo permite realizar o cadastro de escolas, turmas e alunos.
        Selecione uma opção no menu à esquerda para começar.
    ''')

    # Carrega os dados das escolas, turmas e alunos
    schools_df = load_data('./banco_dados/escolas.csv')
    classes_df = load_data('./banco_dados/turmas.csv')
    students_df = load_data('./banco_dados/alunos.csv')

    # Faz o merge dos dados em um único DataFrame
    df = pd.merge(schools_df, classes_df, on='school_id', how='outer')
    df = pd.merge(df, students_df, on=['school_id', 'class_id'], how='outer')

    st.markdown('## Visão Geral')
    st.write(df)

    st.markdown('## Instruções')
    st.markdown('''
        1. Selecione o tipo de cadastro no menu à esquerda (Escola, Turma ou Aluno).
        2. Preencha os campos necessários.
        3. Clique no botão "Cadastrar" para salvar as informações.
        4. Você pode visualizar todas as informações cadastradas na página principal.
    ''')

    st.markdown('## Contato/Suporte')
    st.markdown('''
        Se você encontrar algum problema ou tiver alguma sugestão, entre em contato conosco pelo e-mail suporte@cadastroescolar.com.
    ''')

if __name__ == "__main__":
    main()
