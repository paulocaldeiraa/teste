# Importa as bibliotecas necessárias
import streamlit as st
import sqlalchemy as db
import uuid
import PySimpleGUI as sg
import pandas as pd
import os
import uuid

# Função para salvar informações da turma
def save_class(school_id, class_info):
    unique_id = str(uuid.uuid4())  # Gera um ID único
    class_info['class_id'] = unique_id  # Adiciona o ID único ao dicionário class_info
    class_info['school_id'] = school_id  # Adiciona o ID da escola ao dicionário

    # Verifica se o arquivo 'turmas.csv' existe
    if os.path.exists('./banco_dados/turmas.csv'):
        # Se existir, carrega o arquivo
        classes_df = pd.read_csv('./banco_dados/turmas.csv')
    else:
        # Se não existir, cria um novo DataFrame com as colunas especificadas e salva como 'turmas.csv'
        classes_df = pd.DataFrame(columns=list(class_info.keys()))
        classes_df.to_csv('./banco_dados/turmas.csv', index=False)

    # Cria uma nova linha com as informações da turma e adiciona ao DataFrame
    new_row = pd.DataFrame(class_info, index=[0])
    classes_df.loc[len(classes_df)] = new_row.iloc[0]

    # Reorganiza as colunas para tornar 'school_id' e 'class_id' as primeiras colunas
    cols = ['school_id', 'class_id'] + [col for col in classes_df.columns if col not in ['school_id', 'class_id']]
    classes_df = classes_df[cols]

    # Salva o DataFrame atualizado como 'turmas.csv'
    classes_df.to_csv('./banco_dados/turmas.csv', index=False)
    return None

# Função para registrar uma nova turma
def register_class():
    # Verifica se o arquivo 'escolas.csv' existe antes de tentar carregá-lo
    if not os.path.exists('./banco_dados/escolas.csv'):
        st.error('Escola ainda não cadastrada.')
        return

    # Carrega o arquivo 'escolas.csv'
    schools_df = pd.read_csv('./banco_dados/escolas.csv')

    # Cria um dicionário para mapear os IDs e os nomes de cada escola
    school_dict = pd.Series(schools_df.school_id.values, index=schools_df['nome']).to_dict()

    # Exibe o nome das escolas na interface do Streamlit e permite ao usuário selecionar uma escola
    selected_school_name = st.selectbox('Selecione a Escola *', list(school_dict.keys()))

    # Obtém o ID da escola selecionada 
    school_id = school_dict[selected_school_name]

    class_info = {}    

    # Permite ao usuário selecionar o nível de ensino da turma
    class_info['escolaridade'] = st.selectbox('Selecione o Nível do Ensino *', ['Fundamental 1','Fundamental 2','Médio'],
                                              index=None, placeholder='Selecione o Nível do Ensino')

    if class_info['escolaridade']:
    # Mapeia cada nível de ensino às suas séries correspondentes e permite ao usuário selecionar a série da turma
        series_options = {'Fundamental 1': ['1° Ano','2° Ano', '3° Ano','4° Ano','5° Ano'],
                          'Fundamental 2': ['6° Ano','7° Ano', '8° Ano','9° Ano'],
                          'Médio': ['1° Ano','2° Ano','3° Ano']}
        class_info['serie'] = st.selectbox('Qual série? *', series_options[class_info['escolaridade']],
                                           index=None, placeholder=f'Qual série do {class_info["escolaridade"]}?')
        class_info['turma'] = st.text_input('Turma *')

# Quando o usuário clica no botão "Cadastrar Turma"

    if class_info['escolaridade'] and class_info['serie'] and class_info['turma']:
        if st.button("Cadastrar Turma"):
            if not os.path.exists('./banco_dados/turmas.csv'):
                classes_df = pd.DataFrame(columns=['school_id', 'class_id', 'turma', 'escolaridade', 'serie'])
            else:
                classes_df = pd.read_csv('./banco_dados/turmas.csv')
                if 'school_id' not in classes_df.columns:
                    classes_df['school_id'] = pd.Series(dtype='str')
            if 'turma' in class_info and class_info['turma']:
                if class_info['turma'] in classes_df.loc[classes_df['school_id'] == school_id, 'turma'].values:
                    st.error('Turma já cadastrada para essa Escola.')
                else:
                    save_class(school_id, class_info)

