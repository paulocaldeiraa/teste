# Importa as bibliotecas necessárias
import streamlit as st
import sqlalchemy as db
import pandas as pd
import uuid
import os

def save_results(results_df, school_info):
    unique_id = str(uuid.uuid4())  # Gera o ID único
    school_info['school_id'] = unique_id  # Adiciona o ID no dicionário school_info

    # Adiciona as informações da escola ao DataFrame
    results_df.loc[len(results_df)] = school_info

    # Cria uma nova lista de nomes de colunas com "ID" como a primeira.
    cols = ['school_id'] + [col for col in results_df.columns if col != 'school_id']
    results_df = results_df[cols] # Reorganiza as colunas do DF 

    results_df.to_csv('./banco_dados/escolas.csv', index=False)
    return results_df  # Retorna o DataFrame atualizado

# Para ler os dados da planilha
@st.cache_resource()
def load_data():
    if os.path.exists('./banco_dados/escolas.csv'):
        df = pd.read_csv('./banco_dados/escolas.csv')
    else:
        df = pd.DataFrame(columns=['school_id', 'nome', 'ano', 'turno', 'estado', 'cidade', 'logradouro', 'numero', 'bairro'])
        df.to_csv('./banco_dados/escolas.csv', index=None)
    return df

def register_school():    
    school_info = {}
    school_info['nome'] = st.text_input('Nome da Escola *')

    # Only accept integer values for "Ano de atuação" and "Número"
    school_info['ano'] = st.selectbox('Ano de atuação *', [2023,2024,2025,2026],
                                      index=None, placeholder='Selecione o ano')
        
    # Only accept values from a predefined list for "Turno de trabalho"
    school_info['turno'] = st.selectbox('Turno de trabalho *', ['Manhã', 'Tarde', 'Noite'],
                                        index=None, placeholder='Selecione o turno')
    st.write('**Adicione informações sobre o endereço da escola.**')
    school_info['estado'] = st.selectbox('Estado *', ['Acre',
                                                    'Alagoas',
                                                    'Amapá',
                                                    'Amazonas',
                                                    'Bahia',
                                                    'Ceará',
                                                    'Distrito Federal',
                                                    'Espírito Santo',
                                                    'Goiás',
                                                    'Maranhão',
                                                    'Mato Grosso',
                                                    'Mato Grosso do Sul',
                                                    'Minas Gerais',
                                                    'Pará',
                                                    'Paraíba',
                                                    'Paraná',
                                                    'Pernambuco',
                                                    'Piauí',
                                                    'Rio de Janeiro',
                                                    'Rio Grande do Norte',
                                                    'Rio Grande do Sul',
                                                    'Rondônia',
                                                    'Roraima',
                                                    'Santa Catarina',
                                                    'São Paulo',
                                                    'Sergipe',
                                                    'Tocantins'],index=None, placeholder='Selecione o estado')

    school_info['cidade'] = st.text_input('Cidade *')
    school_info['logradouro'] = st.text_input('Logradouro')
    school_info['numero'] = st.number_input('Número', step=10)
    school_info['bairro'] = st.text_input('Bairro')
    # Criação de campos obrigatórios para habilitar o botão de cadastro
    if school_info['nome'] and school_info['ano'] and school_info['turno'] and school_info['estado'] and school_info['cidade']:
        if st.button("Cadastrar Escola"):
            results_df = load_data()
            if school_info['nome'] in results_df['nome'].values:
                st.error('Escola já cadastrada no banco de dados.')
            else:
                save_results(results_df, school_info)        
