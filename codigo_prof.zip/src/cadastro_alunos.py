import streamlit as st
import pandas as pd
import os
import datetime

# Função para salvar as informações do aluno no arquivo CSV
def save_student(results_df, student_info):
    '''
    Cria uma nova linha com as informações do aluno e adiciona ao DataFrame - 2
    Reorganiza as colunas para tornar 'student_id', 'school_id' e 'class_id' as primeiras colunas - 3
    Salva o DataFrame atualizado como um arquivo CSV - 4
    '''
    new_row = pd.DataFrame(student_info, index=[0])  #2
    results_df = pd.concat([results_df, new_row], ignore_index=True)  #2
    cols = ['school_id', 'class_id'] + [col for col in results_df.columns if col not in ['school_id', 'class_id']] #3
    results_df = results_df[cols] #3
    results_df.to_csv('./banco_dados/alunos.csv', index=False) #4
    return None

def register_student():
    '''
    Verifica se os arquivos CSV das escolas e turmas existem antes de tentar carregá-los.
    Em seguida, carrega os arquivos CSV das escolas e turmas. 
    Depois cria um dicionário para mapear os IDs e os nomes de cada escola, 
    assim permite ao usuário selecionar uma escola das opções disponíveis.
    Por fim, habilita o usuário a inserir as informações do aluno, então essas informações são salvas no csv.
    '''
    if not os.path.exists('./banco_dados/escolas.csv') or not os.path.exists('./banco_dados/turmas.csv'):
        st.error('Sem escola ou turma cadastradas ainda.')
        return

    schools_df = pd.read_csv('./banco_dados/escolas.csv')
    classes_df = pd.read_csv('./banco_dados/turmas.csv')

    school_dict = pd.Series(schools_df.school_id.values, index=schools_df['nome']).to_dict()

    selected_school_name = st.selectbox('Selecione a Escola', list(school_dict.keys()), index=None, placeholder='Escolha uma opção')
    telefone = ''
    student_info = {'nome': '', 'sexo': '', 'nascimento': '', 'telefone': ''}

    if selected_school_name:
        school_id = school_dict[selected_school_name]
         
        # Filtra as turmas com base na escola selecionada
        filtered_classes_df = classes_df[classes_df['school_id'] == school_id]
        class_dict = pd.Series(filtered_classes_df.class_id.values,
        index='Ensino '+ filtered_classes_df['escolaridade'].astype(str) + ' - Série ' + filtered_classes_df['serie'].astype(str) + ' - Turma ' + filtered_classes_df['turma'].astype(str)).to_dict()

        selected_class_name = st.selectbox('Selecione a Turma', list(class_dict.keys()),index=None, placeholder='Escolha uma opção')
        if selected_class_name:
            class_id = class_dict[selected_class_name]
            student_info['school_id'] = school_id
            student_info['class_id'] = class_id
            student_info['nome'] = st.text_input('Nome do Aluno *')
            student_info['sexo'] = st.selectbox('Sexo *', ['Masculino', 'Feminino'], index=None, placeholder='Escolha uma opção')
            student_info['nascimento'] = st.date_input('Data de nascimento *', min_value=datetime.date(1900,1,1))
            telefone = st.text_input('Telefone', max_chars=11)
            erro_telefone = False
            if not telefone.isdigit() and telefone != '':
                st.error('Por favor, insira apenas números para o telefone.')
                erro_telefone = True
            else:
                student_info['telefone'] = telefone

        # Verifica se os campos obrigatórios estão preenchidos e se não há erro de telefone
        if student_info['nome'] and student_info['sexo'] and student_info['nascimento']:
            
            if st.button("Cadastrar Aluno"):
                if not os.path.exists('./banco_dados/alunos.csv'):
                    students_df = pd.DataFrame(columns=['school_id', 'class_id', 'nome', 'sexo', 'nascimento', 'telefone'])
                else:
                    students_df = pd.read_csv('./banco_dados/alunos.csv')
                    if 'school_id' not in students_df.columns:
                        students_df['school_id'] = pd.Series(dtype='str')
                if 'nome' in student_info and student_info['nome']:
                    if student_info['nome'] in students_df.loc[students_df['school_id'] == school_id, 'nome'].values:
                        st.error('Esse aluno já está cadastrado na Escola.')
                    else:
                        save_student(students_df, student_info)
