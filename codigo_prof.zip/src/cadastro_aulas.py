# Importa as bibliotecas necessárias
import streamlit as st
import pandas as pd
import os
import uuid
from fpdf import FPDF
from src.cadastro_turmas import register_class

# Função para salvar informações da aula
def save_lesson(lesson_info):
    unique_id = str(uuid.uuid4())  # Gera um ID único
    lesson_info['lesson_id'] = unique_id  # Adiciona o ID único ao dicionário lesson_info

    # Verifica se o arquivo 'aulas.csv' existe
    if os.path.exists('./banco_dados/aulas.csv'):
        # Se existir, carrega o arquivo
        lessons_df = pd.read_csv('./banco_dados/aulas.csv')
    else:
        # Se não existir, cria um novo DataFrame com as colunas especificadas e salva como 'aulas.csv'
        lessons_df = pd.DataFrame(columns=list(lesson_info.keys()))
        lessons_df.to_csv('./banco_dados/aulas.csv', index=False)

    # Cria uma nova linha com as informações da aula e adiciona ao DataFrame
    new_row = pd.DataFrame(lesson_info, index=[0])
    lessons_df.loc[len(lessons_df)] = new_row.iloc[0]

    # Reorganiza as colunas para tornar 'lesson_id' a primeira coluna
    cols = ['lesson_id'] + [col for col in lessons_df.columns if col != 'lesson_id']
    lessons_df = lessons_df[cols]

    # Salva o DataFrame atualizado como 'aulas.csv'
    lessons_df.to_csv('./banco_dados/aulas.csv', index=False)
    return None

# Função para criar um PDF com as informações da aula
def create_lesson_pdf(lesson_info):
    pdf = FPDF()

    pdf.add_page()

    pdf.set_font("Arial", size=12)
    
    for key, value in lesson_info.items():
        if key != 'lesson_id':
            # Converte o valor em string antes de adicioná-lo ao PDF
            pdf.cell(200, 10, txt=key + ": " + str(value), ln=True)

    pdf.output("./banco_dados/" + lesson_info['lesson_id'] + ".pdf")

# Página de cadastro de aulas do aplicativo Streamlit
def register_lesson():
    """Cria uma página de cadastro de aulas usando a biblioteca Streamlit.

    Returns:
        None
    """
    
    lesson_info = {}

    series_options = {'Fundamental 1': ['1° Ano','2° Ano', '3° Ano','4° Ano','5° Ano'],
                          'Fundamental 2': ['6° Ano','7° Ano', '8° Ano','9° Ano'],
                          'Médio': ['1° Ano','2° Ano','3° Ano']}
    
    st.markdown ('### I. Identificação')
    lesson_info['professor'] = st.text_input('Nome do Professor')
    lesson_info['disciplina'] = st.selectbox('Disciplina', ['Portugês', 'Matemática', 'Biologia', 'Química',
                                                            'Física', 'Ciências'], index=None, 
                                                            placeholder='Selecione uma opção')
    lesson_info['nivel_ensino'] = st.selectbox('Nível de Ensino', ['Fundamental 1', 'Fundamental 2', 'Ensino Médio'],index=None, 
                                                            placeholder='Selecione uma opção' )
    
    if lesson_info['nivel_ensino'] == 'Fundamental 1':
        lesson_info['serie'] = st.selectbox('Série', series_options['Fundamental 1'],index=None, 
                                            placeholder='Selecione uma opção' )

    if lesson_info['nivel_ensino'] == 'Fundamental 2':
        lesson_info['serie'] = st.selectbox('Série', series_options['Fundamental 2'],index=None, 
                                            placeholder='Selecione uma opção' )
        
    if lesson_info['nivel_ensino'] == 'Ensino Médio':
        lesson_info['serie'] = st.selectbox('Série', series_options['Ensino Médio'],index=None, 
                                            placeholder='Selecione uma opção' )
        

    lesson_info['data'] = st.text_input('Data')   
    lesson_info['escola'] = st.text_input('Nome da Escola')

    st.markdown ('### II. Tema da Aula')
    lesson_info['titulo_da_aula'] = st.text_input('Título da Aula')

    st.markdown('### III. Objetivo Geral')    
    lesson_info['objetivos_da_aula'] = st.text_area('Objetivos da Aula')
    
    st.markdown('### IV. Introdução') 
    lesson_info['conteudo_da_aula'] = st.text_area('Conteúdo da Aula')
    
    st.markdown('### V. Desenvolvimento')
    lesson_info['metodos_de_ensino'] = st.text_area('Métodos de Ensino')
    lesson_info['recursos_necessarios'] = st.text_area('Recursos Necessários')
    
    st.markdown('### Avaliação')
    lesson_info['avaliacao_e_feedback'] = st.text_area('Avaliação e Feedback')
    lesson_info['observacoes'] = st.text_area('Observações')

    uploaded_file = st.file_uploader("Escolha um arquivo")
    
    if uploaded_file is not None:
        with open(os.path.join("./banco_dados/", uploaded_file.name), "wb") as f:
            f.write(uploaded_file.getbuffer())
        st.success("Arquivo salvo em ./banco_dados/")

    if st.button("Cadastrar Aula"):
        save_lesson(lesson_info)
        create_lesson_pdf(lesson_info)
        st.success("Aula cadastrada com sucesso!")






