import streamlit as st
import pandas as pd
import os
import uuid
from fpdf import FPDF
from src.cadastro_aulas import register_lesson

# Função para salvar informações da aula
def save_lesson(lesson_info):
    unique_id = str(uuid.uuid4())  # Gera um ID único
    lesson_info['lesson_id'] = unique_id  # Adiciona o ID único ao dicionário lesson_info

    # Verifica se o arquivo 'aulas.csv' existe
    if os.path.exists('./banco_dados/aulas.csv'):
        # Se existir, carrega o arquivo
        lessons_df = pd.read_csv('./banco_dados/aulas.csv')
    else:
        # Se não existir, cria um novo DataFrame com as colunas especificadas e salva como 'aulas.csv'
        lessons_df = pd.DataFrame(columns=list(lesson_info.keys()))
        lessons_df.to_csv('./banco_dados/aulas.csv', index=False)

    # Cria uma nova linha com as informações da aula e adiciona ao DataFrame
    new_row = pd.DataFrame(lesson_info, index=[0])
    lessons_df.loc[len(lessons_df)] = new_row.iloc[0]

    # Reorganiza as colunas para tornar 'lesson_id' a primeira coluna
    cols = ['lesson_id'] + [col for col in lessons_df.columns if col != 'lesson_id']
    lessons_df = lessons_df[cols]

    # Salva o DataFrame atualizado como 'aulas.csv'
    lessons_df.to_csv('./banco_dados/aulas.csv', index=False)
    return None

# Função para criar um PDF com as informações da aula
def create_pdf(lesson_info):
    pdf = FPDF()

    pdf.add_page()

    pdf.set_font("Arial", size=12)
    
    for key, value in lesson_info.items():
        if key != 'lesson_id':
            pdf.cell(200, 10, txt=key + ": " + str(value), ln=True)

    pdf.output("./banco_dados/" + lesson_info['lesson_id'] + ".pdf")

# Página de cadastro de aulas do aplicativo Streamlit
register_lesson()

