# Importa as bibliotecas necessárias
import streamlit as st
import pandas as pd
from src.cadastro_escolas import register_school
from src.cadastro_turmas import register_class
from src.cadastro_alunos import register_student


# ---------- CONFIGURAÇÃO GERAL DO STREAMLIT ----------# 
    # Configuração geral do Streamlit
st.title('Cadastrar nova Entrada')
st.markdown('Aqui é possível realizar o cadastro de um novo registro. \
            Para começar selecione o tipo de entrada, em seguida preencha \
            os dados solicitados e clique no botão para salvar as informações')

# # Habilita o editor na barra lateral da página
# sidebar_editor()

# Se a opção de edição não estiver ativa, permite um novo cadastro

register_type = st.selectbox('Selecione o tipo de cadastro',
            index=None,
            placeholder="Selecione uma opção para começar",
            options=['Escola', 'Turma', 'Aluno'])

# Usa as funções para liberar os inputs e em seguida salvá-los nos respectivos bancos de dados.
if register_type == 'Escola':
    register_school()
elif register_type == 'Turma':
    register_class()
elif register_type == 'Aluno':
    register_student()
