import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QLabel, QLineEdit, QPushButton, QGridLayout
from PyQt5.QtSql import QSqlDatabase, QSqlQuery
from PyQt5.QtWidgets import QDialog

class App(QApplication):
    def __init__(self):
        super().__init__(sys.argv)
        self.main_window = MainWindow()
        self.main_window.show()

        sys.exit(self.exec_())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Configurações da janela principal
        self.setWindowTitle("Aplicativo Escolar")
        self.setGeometry(500, 200, 500, 500)

        # Cria a interface do usuário
        self.central_widget = QWidget()
        self.grid_layout = QGridLayout(self.central_widget)

        # Label de título
        self.label_titulo = QLabel("Aplicativo Escolar")
        self.grid_layout.addWidget(self.label_titulo, 0, 0)

        # Botão para cadastro de alunos
        self.button_cadastro_alunos = QPushButton("Cadastro de Alunos")
        self.grid_layout.addWidget(self.button_cadastro_alunos, 1, 0)

        # Botão para cadastro de escolas
        self.button_cadastro_escolas = QPushButton("Cadastro de Escolas")
        self.grid_layout.addWidget(self.button_cadastro_escolas, 2, 0)

        # Botão para cadastro de turmas
        self.button_cadastro_turmas = QPushButton("Cadastro de Turmas")
        self.grid_layout.addWidget(self.button_cadastro_turmas, 3, 0)

        # Botão para cadastro de aulas
        self.button_cadastro_aulas = QPushButton("Cadastro de Aulas")
        self.grid_layout.addWidget(self.button_cadastro_aulas, 4, 0)

        # Define a interface principal como o widget central
        self.setCentralWidget(self.central_widget)


# Conecta os eventos dos botões
def conectar_eventos(self):
    self.button_cadastro_alunos.clicked.connect(self.abrir_cadastro_alunos)
    self.button_cadastro_escolas.clicked.connect(self.abrir_cadastro_escolas)
    self.button_cadastro_turmas.clicked.connect(self.abrir_cadastro_turmas)
    self.button_cadastro_aulas.clicked.connect(self.abrir_cadastro_aulas)


# Abre o formulário de cadastro de alunos
def abrir_cadastro_alunos(self):
    # TODO: Implementar o formulário de cadastro de alunos
    print("Abrindo o formulário de cadastro de alunos")


# Abre o formulário de cadastro de escolas
def abrir_cadastro_escolas(self):
    # Cria o formulário de cadastro de escolas
    self.form_cadastro_escolas = EscolaCadastroForm(self)
    self.form_cadastro_escolas.show()


# Abre o formulário de cadastro de turmas
def abrir_cadastro_turmas(self):
    # TODO: Implementar o formulário de cadastro de turmas
    print("Abrindo o formulário de cadastro de turmas")


# Abre o formulário de cadastro de aulas
def abrir_cadastro_aulas(self):
    # TODO: Implementar o formulário de cadastro de aulas
    print("Abrindo o formulário de cadastro de aulas")


# Inicia o aplicativo
if __name__ == "__main__":
    app = App()
    conectar_eventos(app)
    app.exec_()

class EscolaCadastroForm(QDialog):
    def __init__(self, parent):
        super().__init__(parent)

        # Configurações da janela
        self.setWindowTitle("Cadastro de Escolas")
        self.setGeometry(500, 200, 500, 500)

        # Cria a interface do formulário de cadastro de escolas
        self.grid_layout = QGridLayout()

        # Label do nome da escola
        self.label_nome_escola = QLabel("Nome da escola:")
        self.grid_layout.addWidget(self.label_nome_escola, 0, 0)

        # Linha de edição do nome da escola
        self.lineEdit_nome_escola = QLineEdit()
        self.grid_layout.addWidget(self.lineEdit_nome_escola, 0, 1)

        # Label do ano de atuação
        self.label_ano_atuacao = QLabel("Ano de atuação:")
        self.grid_layout.addWidget(self.label_ano_atuacao, 1, 0)

        # Linha de edição do ano de atuação
        self.lineEdit_ano_atuacao = QLineEdit()
        self.grid_layout.addWidget(self.lineEdit_ano_atuacao, 1, 1)

        # Label do turno
        self.label_turno = QLabel("Turno:")
        self.grid_layout.addWidget(self.label_turno, 2, 0)

        # Linha de edição do turno
        self.lineEdit_turno = QLineEdit()
        self.grid_layout.addWidget(self.lineEdit_turno, 2, 1)

        # Label do endereço
        self.label_endereco = QLabel("Endereço:")
        self.grid_layout.addWidget(self.label_endereco, 3, 0)

        # Linha de edição do endereço
        self.lineEdit_endereco = QLineEdit()
        self.grid_layout.addWidget(self.lineEdit_endereco, 3, 1)

        # Botão para salvar a escola
        self.button_salvar = QPushButton("Salvar")
        self.grid_layout.addWidget(self.button_salvar, 4, 0)

        # Conecta o evento do botão de salvar
        self.button_salvar.clicked.connect(self.salvar_escola)

        # Exibe a janela do formulário de cadastro de escolas
        self.show()


    def salvar_escola(self):
        # Verifica se os campos obrigatórios foram preenchidos
        if self.lineEdit_nome_escola.text() == "" or self.lineEdit_ano_atuacao.text() == "" or self.lineEdit_turno.text() == "":
            return

        # Adiciona um print() para verificar se o método está sendo chamado
        print("Método salvar_escola() chamado")

        # Cria uma conexão com o banco de dados
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("escola.db")
        db.open()

        # Cria uma query para inserir a escola no banco de dados
        query = QSqlQuery(db)
        query.prepare("INSERT INTO escolas (nome, ano_atuacao, turno, endereco) VALUES (?, ?, ?, ?)")
        query.bindValue(0, self.lineEdit_nome_escola.text())
        query.bindValue(1, self.lineEdit_ano_atuacao.text())
        query.bindValue(2, self.lineEdit_turno.text())
        query.bindValue(3, self.lineEdit_endereco.text())

        # Executa a query
        query.exec_()

        # Fecha a conexão com o banco de dados
        db.close()

        # Fecha o formulário de cadastro de escolas
        self.close()
