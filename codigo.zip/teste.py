import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QLabel, QLineEdit, QPushButton, QGridLayout
from PyQt5.QtSql import QSqlDatabase, QSqlQuery
from src.cadastro_escola import EscolaCadastroForm

class App(QApplication):
    def __init__(self):
        super().__init__(sys.argv)
        self.main_window = MainWindow()
        self.main_window.show()

        sys.exit(self.exec_())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Configurações da janela principal
        self.setWindowTitle("Aplicativo Escolar")
        self.setGeometry(500, 200, 500, 500)

        # Cria a interface do usuário
        self.central_widget = QWidget()
        self.grid_layout = QGridLayout(self.central_widget)

        # Label de título
        self.label_titulo = QLabel("Aplicativo Escolar")
        self.grid_layout.addWidget(self.label_titulo, 0, 0)

        # Botão para cadastro de alunos
        self.button_cadastro_alunos = QPushButton("Cadastro de Alunos")
        self.grid_layout.addWidget(self.button_cadastro_alunos, 1, 0)

        # Botão para cadastro de escolas
        self.button_cadastro_escolas = QPushButton("Cadastro de Escolas")
        self.grid_layout.addWidget(self.button_cadastro_escolas, 2, 0)

        # Botão para cadastro de turmas
        self.button_cadastro_turmas = QPushButton("Cadastro de Turmas")
        self.grid_layout.addWidget(self.button_cadastro_turmas, 3, 0)

        # Botão para cadastro de aulas
        self.button_cadastro_aulas = QPushButton("Cadastro de Aulas")
        self.grid_layout.addWidget(self.button_cadastro_aulas, 4, 0)

        # Define a interface principal como o widget central
        self.setCentralWidget(self.central_widget)


# Conecta os eventos dos botões
def conectar_eventos(self):
    self.button_cadastro_alunos.clicked.connect(self.abrir_cadastro_alunos)
    self.button_cadastro_escolas.clicked.connect(self.abrir_cadastro_escolas)
    self.button_cadastro_turmas.clicked.connect(self.abrir_cadastro_turmas)
    self.button_cadastro_aulas.clicked.connect(self.abrir_cadastro_aulas)


# Abre o formulário de cadastro de alunos
def abrir_cadastro_alunos(self):
    # TODO: Implementar o formulário de cadastro de alunos
    print("Abrindo o formulário de cadastro de alunos")


# Abre o formulário de cadastro de escolas
def abrir_cadastro_escolas(self):
    # TODO: Implementar o formulário de cadastro de escolas
    self.form_cadastro_escolas = EscolaCadastroForm(self)
    self.form_cadastro_escolas.show()
    print("Abrindo o formulário de cadastro de escolas")


# Abre o formulário de cadastro de turmas
def abrir_cadastro_turmas(self):
    # TODO: Implementar o formulário de cadastro de turmas
    print("Abrindo o formulário de cadastro de turmas")


# Abre o formulário de cadastro de aulas
def abrir_cadastro_aulas(self):
    # TODO: Implementar o formulário de cadastro de aulas
    print("Abrindo o formulário de cadastro de aulas")


# Inicia o aplicativo
if __name__ == "__main__":
    app = App()
    conectar_eventos(app)
    app.exec_()
